# -*- coding: utf-8 -*-
from core.libs import *

def get_video_url(item):
    logger.trace()
    itemlist = []

    if 'storage.googleapis.com' in item.url or 'storage.cloud.google.com' in item.url:
        # Google Cloud Storage
        itemlist.append(Video(url=item.url))

    else:
        # Google Drive
        try:
            # Metodo 1
            id = scrapertools.find_single_match(item.url, '&id=(.*?)$')
            url = "http://docs.google.com/get_video_info?docid=" + id

            data = httptools.downloadpage(url, cookies=False, headers={"Referer": item.url})
            cookies = ''.join(scrapertools.find_multiple_matches(data.headers["set-cookie"],
                                                                 "(DRIVE_STREAM=[^;]+;|NID=[^;]+;)"))

            data = urllib.unquote_plus(urllib.unquote_plus(data.data.decode('unicode-escape')))
            videos_list = scrapertools.find_multiple_matches(scrapertools.find_single_match(data,
                                    'url_encoded_fmt_stream_map=(.*)'),
                                    'itag=(\d+)&url=(.*?)(?:;.*?quality=.*?(?:,|&)|&quality=.*?(?:,|&))')

            res = {'18': '360p', '34': '360p', '43': '360p',
                   '35': '480p', '59': '480p',
                   '22': '720p',
                   '37': '1080p'}

            for itag, url in videos_list:
                type = scrapertools.find_single_match(url, '&mime=video/([^&]+)')
                itemlist.append(Video(url=url+"|Cookie=" + cookies, res=res.get(itag), type=type))

        except:
            # Metodo 2
            itemlist = ()
            data = httptools.downloadpage(item.url).data

            url = scrapertools.find_single_match(data, 'href="(/uc\?export=download&confirm=[^&]+&id=[^"]+)"')
            url = httptools.downloadpage(urlparse.urljoin(item.url, url), only_headers=True,
                                         follow_redirects=False).headers['location']

            filename = httptools.downloadpage(url, only_headers=True,
                                              follow_redirects=False).headers['content-disposition']
            ext = scrapertools.find_single_match(filename, 'filename="[^"]+\.([^".]+)"')
            itemlist.append(Video(url=url, type=ext))

    return itemlist
